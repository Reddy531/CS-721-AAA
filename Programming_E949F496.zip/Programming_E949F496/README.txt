This is a JAVA Program to perform Binary Search Operation.
Steps:
	1. Unzip the File
	2. Open specific folder in command prompt
	2. Compile BSTImplementation.java file in command prompt
		javac BSTImplementation.java
	3. Execute BSTImplementation.java file
		java BSTImplementation
	4. All the BST operations will be listed
